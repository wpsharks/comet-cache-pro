
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","__()"],["f","plugin()"],["c","quick_cache\\actions"],["c","quick_cache\\advanced_cache"],["c","quick_cache\\auto_cache"],["c","quick_cache\\menu_pages"],["c","quick_cache\\plugin"],["f","quick_cache_php53_dashboard_notice()"],["c","websharks\\html_compressor\\core"],["f","wp_cache_postload()"]];
